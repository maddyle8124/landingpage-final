
// This file is no longer needed as it has been replaced by AboutPage.tsx
export {};